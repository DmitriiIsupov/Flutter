package com.myiotcompany.iotstarterkitapp.iot_starter_kit_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
