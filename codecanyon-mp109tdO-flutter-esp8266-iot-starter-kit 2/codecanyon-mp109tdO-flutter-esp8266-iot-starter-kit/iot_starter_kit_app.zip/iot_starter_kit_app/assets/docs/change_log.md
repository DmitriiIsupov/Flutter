# This is Change Log file

You can place change log about the app here. For example:

* Logo added
* About Screen implemented
* Settings Screen updated and some settings moved to About Screen
